#!/bin/bash

rm /etc/localtime
ln -sf /usr/share/zoneinfo/Canada/Eastern /etc/localtime
hwclock --systohc

locale-gen "en_CA.UTF-8"

echo "LANG=en_CA.UTF-8" >> /etc/locale.conf

echo KEYMAP=us >> /etc/vconsole.conf

echo Aite >> /etc/hostname

echo "127.0.0.1  localhost" >> /etc/hosts
echo "::1" >> /etc/hosts
echo "127.0.0.1  Aite.local   Aite" >> /etc/hosts

echo "Root password"
passwd

# Install essential packages
pacman -S vim openssh git sudo lightdm tree intel-ucode
pacman -S weston gnome gnome-extra

# Configure mkinitcpio
sed -i '/HOOKS\=/d' /etc/mkinitcpio.conf
sed -i '/\#/d' /etc/mkinitcpio.conf
echo "HOOKS=(base udev autodetect keyboard keymap consolefont modconf block encrypt lvm2 filesystems fsck)" >> /etc/mkinitcpio.conf

mkinitcpio -p linux

bootctl --path=/boot install

rm /boot/loader/loader.conf
touch /boot/loader/loader.conf

echo "default arch
timeout 0
editor  no" >> /boot/loader/loader.conf

touch /boot/loader/entries/arch.conf

fs_uuid=$(blkid -o value -s UUID /dev/sda2)

# Set up arch conf file for boot loader
echo "title Arch Linux
linux /vmlinuz-linux
initrd /intel-ucode.img
initrd /initramfs-linux.img
options cryptdevice=UUID=${fs_uuid}:cryptvg root=/dev/cryptvg/root rw" >> /boot/loader/entries/arch.conf

# Start ssh service
systemctl enable sshd.service

# TODO Conditional DE [MATE or GNOME]

useradd --create-home --groups wheel --shell /bin/bash stndrs
echo "User password"
passwd stndrs

echo "%wheel ALL=(ALL) ALL" >> /etc/sudoers

cp arch_user_setup.sh /home/stndrs/
su - stndrs /home/stndrs/arch_user_setup.sh

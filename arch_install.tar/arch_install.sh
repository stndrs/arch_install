#!/bin/bash

echo "Enter the device you want to install arch linux to:"
read device
echo "Arch will be installed on ${device}. Hit enter to continue"

timedate set-ntp true

# Disk partitioning
# More info: https://www.rodsbooks.com/gdisk/sgdisk-walkthrough.html

# Convert disk to GPT and clear disk
sgdisk -go ${device}

# Create boot partition
FIRSTSECTOR=`sgdisk -F ${device}`
sgdisk -n 1:${FIRSTSECTOR}:+500M -c 1:"boot" -t 1:ef00 ${device}

# Create partition for luks
NEXTSECTOR=`sgdisk -f ${device}`
ENDSECTOR=`sgdisk -E ${device}`
sgdisk -n 2:${NEXTSECTOR}:${ENDSECTOR} -c 2:"luks" -t 1:8e00 ${device}

# Set up luks
cryptsetup luksFormat --type luks2 ${device}2
cryptsetup open ${device}2 cryptlvm

pvcreate /dev/mapper/cryptlvm
vgcreate cryptvg /dev/mapper/cryptlvm

# Create logical volumes for swap /root and/home
echo "How big should the swap parition be? [n]{MG}"
read SWAP
lvcreate -L ${SWAP} cryptvg -n swap

echo "How big should the root partition be? [n]{MG}"
read ROOT
lvcreate -L ${ROOT} cryptvg -n root
lvcreate -l 100%FREE cryptvg -n home

# Format partitions
mkfs.fat -F32 ${device}1
mkfs.ext4 /dev/cryptvg/root
mkfs.ext4 /dev/cryptvg/home
mkswap /dev/cryptvg/swap

mount /dev/cryptvg/root /mnt
mkdir /mnt/home
mount /dev/cryptvg/home /mnt/home
swapon /dev/cryptvg/swap
mkdir /mnt/boot
mount ${device}1 /mnt/boot

pacstrap /mnt base base-devel

genfstab -U /mnt >> /mnt/etc/fstab


cp arch_setup.sh /mnt
cp arch_user_setup.sh /mnt

arch-chroot /mnt ./arch_setup.sh


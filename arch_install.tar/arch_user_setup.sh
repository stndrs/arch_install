#!/bin/bash

git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si

yay -S lightdm-slick-greeter google-chrome ttf-dejavu

sed -i '/greeter-session/d' /etc/lightdm/lightdm.conf
echo "greeter-session=lightdm-slick-greeter" >> /etc/lightdm/lightdm.conf

mv /usr/share/xsessions/gnome.desktop /usr/share/xsessions/gnome.desktop.bak

pacman -S libreoffice-fresh firefox
yay -S visual-studio-code-bin rbenv ruby-build nvm mysql

echo 'source /usr/share/nvm/init-nvm.sh' >> ~/.bashrc
echo 'eval "$(rbenv init -)"' >> ~/.bashrc 
source ~/.bashrc

rbenv install 2.4.1
rbenv global 2.4.1

nvm install 8.10.0
nvm use 8.10.0 

